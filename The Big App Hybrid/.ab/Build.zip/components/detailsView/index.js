'use strict';

app.detailsView = kendo.observable({
    onShow: function() {}
});

// START_CUSTOM_CODE_detailsView
// END_CUSTOM_CODE_detailsView